function hello(name){
	console.log("Hi " + name);
}
hello("Ram");