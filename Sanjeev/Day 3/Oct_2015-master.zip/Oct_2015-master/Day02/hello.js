function sayHello(name){
	return "Hello " + name;
}
function sayBye(name){
	return "Bye Bye " + name;
}