﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MockExLib;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using System.Data;


namespace MockExTest
{
    [TestClass]
    public class UserRepositoryTest
    {
        public UserRepository UserRepo { get; set; }
        [TestInitialize]
        public void Init() {
            UserRepo = new UserRepository();
            UserRepo.ConnectionString = @"Data Source=E4LJBSL3AUMKO\SQLEXPRESS;Initial Catalog=TestDB;Persist Security Info=True;User ID=sa;Password=durasoft;Pooling=False";
            SqlHelper.ExecuteNonQuery(UserRepo.ConnectionString,
                CommandType.Text,
                "Delete from users");
        }
        [TestMethod]
        public void TestSetUp()
        {
            Assert.IsNotNull(UserRepo);
        }
        [TestMethod]
        public void TestConnectionString()
        {
            Assert.IsTrue(UserRepo.ConnectionString == @"Data Source=E4LJBSL3AUMKO\SQLEXPRESS;Initial Catalog=TestDB;Persist Security Info=True;User ID=sa;Password=durasoft;Pooling=False");
        }
        [TestMethod]
        public void TestSaveUser()
        {
            string userName = "root";
            string password = "password";
            bool saved = UserRepo.SaveUser(userName, password);
            Assert.IsTrue(saved);
            SqlDataReader reader = SqlHelper.ExecuteReader(UserRepo.ConnectionString,
                CommandType.Text,
                "select * from users where username='root' and password='password'");
            bool exists = reader.Read();
            Assert.IsTrue(exists);
        }
    }
}
