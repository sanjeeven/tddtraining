﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace MockExLib
{
    public class UserRepository : IUserRepository
    {
        public bool SaveUser(string userName, string password)
        {
            string query = "Insert into users(username,password) values('" + userName + "','" + password + "')";
            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();
            SqlCommand com = con.CreateCommand();
            com.CommandText = query;
            int rowCount = com.ExecuteNonQuery();
            con.Close();
            return rowCount == 1 ? true:false;
        }

        public string ConnectionString { get; set; }
    }
}
